/**
 * Created by LinkFly-user on 14.12.2014.
 */
var qunit = require('qunit');
qunit.run({
    code: "tests.js"
});



